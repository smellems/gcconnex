<?php

echo elgg_view('page/layouts/default', $vars);