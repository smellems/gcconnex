<?php

$body = elgg_extract('body', $vars);
echo $body;