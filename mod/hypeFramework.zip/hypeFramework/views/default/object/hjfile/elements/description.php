<?php

$description = elgg_view('framework/bootstrap/object/elements/description', $vars);
echo $description;