<?php

echo elgg_view('framework/bootstrap/object/elements/tags', $vars);