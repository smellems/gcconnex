<?php

echo elgg_view('framework/bootstrap/object/elements/icon', $vars);