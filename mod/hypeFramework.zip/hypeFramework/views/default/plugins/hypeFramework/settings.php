<?php

$params = elgg_clean_vars($vars);
echo hj_framework_view_form_body('edit:plugin:hypeframework', $params);
