<?php

echo '<div class="elgg-entity-tags">';
echo elgg_view('output/tags', $vars);
echo '</div>';