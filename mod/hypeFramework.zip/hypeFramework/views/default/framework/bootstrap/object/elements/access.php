<?php

echo elgg_view('output/access', $vars);