<?php

echo elgg_view('framework/bootstrap/user/elements/name', $vars);