<?php

echo elgg_view('page/layouts/one_sidebar', $vars);
