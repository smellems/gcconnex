<?php

$body = elgg_extract('body', $vars);
echo "<div class=\"hj-framework-list-wrapper\">$body</div>";