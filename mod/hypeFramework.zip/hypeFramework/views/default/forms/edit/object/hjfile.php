<?php

$params = elgg_clean_vars($vars);
echo hj_framework_view_form('edit:object:hjfile', $params);
