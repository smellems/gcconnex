<?php

echo elgg_view('input/file', $vars);

