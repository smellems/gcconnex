<?php

// CSS and JS
elgg_register_css('forum.base.css', elgg_get_simplecache_url('css', 'framework/forum/base'));
elgg_register_simplecache_view('css/framework/forum/base');

elgg_register_js('forum.base.js', elgg_get_simplecache_url('js', 'framework/forum/base'));
elgg_register_simplecache_view('js/framework/forum/base');
