# hypeForum 1.9

## Introduction

hypeForum 1.9 is a forum and discussions plugin for Elgg.

## Features

- Forum Categories
- Sub-forums
- Forum cover-images
- Sticky topics
- Group forums
- Bookmarked topics
- Subscriptions to forum notifications