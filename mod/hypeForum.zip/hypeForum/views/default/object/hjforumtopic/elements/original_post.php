<?php

echo elgg_view('object/hjforumpost', $vars);
