<style>
.c_table { 
	border:1px solid #ccc;
	background-color:;
}

.table th,td {
	padding:10px;
}

</style>

<?php
echo '<table class="c_table"><tr><td>';
echo '<div>'. elgg_echo('c_polls_msg:notice') .'</div>';
echo '</td></tr></table>';
echo '<br/>';