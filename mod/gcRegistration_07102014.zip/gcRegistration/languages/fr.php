<?php
$french = array(
	'gcRegister:email_initial' => 'Addresse e-mail',
	'gcRegister:email_secondary' => 'Confirmation du mot de passe addresse e-mail',
	'gcRegister:username' => 'Nom d\'utilisateur (généré automatiquement)',
	'gcRegister:password_initial' => 'Mot de passe',
	'gcRegister:password_secondary' => 'Confirmation du mot de passe',
	'gcRegister:display_name' => 'Nom à afficher',
	'gcRegister:email_error' => 'erreur email',
	'gcRegister:password_error' => 'erreur de mot de passe',
	'gcRegister:failedMySQLconnection' => 'erreur de cache: impossible de se connecter à la base de données',
	'gcRegister:email_in_use' => 'Le courriel n\'est pas disponible',
	'gcRegister:invalid_email' => 'adresse de couriel non valide',
	'gcRegister:please_enter_email' => 'S\'il vous plaît entrer email',
	'gcRegister:department_name' => 'Entrez votre département',
	'gcRegister:register' => 'S\'enregistrer',
	'gcRegister:invalid_credential' => 'Oops! Les pouvoirs ne sont pas valides',
	'gcRegister:empty_field' => 'champ vide',
	'gcRegister:mismatch' => 'inadéquation',
	'gcRegister:email_notice' => "<b>NOTA :</b> Les comptes ne peuvent Ãªtres crÃ©Ã©s qu'avec une adresse  couriel valide du gouvernement du Canada. Si vous inscrivez une adresse non valide, vous recevez un avis d'<code>adresse courriel non valide</code>. Si vous croyez que l'adresse courriel du gouvernement du Canada que vous avez utilisÃ©e est valide, veullez communiquer avec GCconnex@tbs-sct.gc.ca",
	'gcRegister:terms_and_conditions' => "J'ai lu, je comprends et j'accepte <a href='http://www.gcpedia.gc.ca/wiki/GCpedia:Conditions_d%27utilisation'>les conditions d'utilisation</a>.",
	'gcRegister:app_error' => "Vous êtes à accepter les termes et conditions d'utilisation",
);

add_translation("fr", $french);