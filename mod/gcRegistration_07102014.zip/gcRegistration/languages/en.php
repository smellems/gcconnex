<?php
$english = array(
	'gcRegister:email_initial' => 'Enter your e-mail',
	'gcRegister:email_secondary' => 'Your e-mail again (verification)',
	'gcRegister:username' => 'Your Username (Auto-Generated)',
	'gcRegister:password_initial' => 'Password',
	'gcRegister:password_secondary' => 'Password (again for verification)',
	'gcRegister:display_name' => 'Display Name',
	'gcRegister:email_error' => 'email error',
	'gcRegister:password_error' => 'password error',
	'gcRegister:failedMySQLconnection' => 'cache error: unable to connect to the database',
	'gcRegister:email_in_use' => 'The email is not available',
	'gcRegister:invalid_email' => 'invalid email',
	'gcRegister:please_enter_email' => 'Please enter email',
	'gcRegister:department_name' => 'Enter your Department',
	'gcRegister:register' => 'Register',
	'gcRegister:invalid_credential' => 'Oops! The credentials are invalid',
	'gcRegister:empty_field' => 'empty field',
	'gcRegister:mismatch' => 'mismatch',
	'gcRegister:email_notice' => '<b>NOTE:</b> Accounts may only be created using a valid Government of Canada email address. If you entered a non-Government of Canada email address you will receive an <code>invalid email</code> notice. If you believe this notice is in error, pleace contact: GCconnex@tbs-sct.gc.ca',
	'gcRegister:terms_and_conditions' => 'I have read, understood, and agree to the <a href="http://www.gcpedia.gc.ca/wiki/GCpedia:Terms_and_conditions_of_use">terms and conditions of use</a>.',
	'gcRegister:app_error' => 'You must accept the Terms and Conditions of Use',
);

add_translation("en", $english);