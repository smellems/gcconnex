<?php

	/* 
	 * Registration page changes
	 */
/***********************************************************************
 * MODIFICATION LOG
 * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 *
 * USER 		DATE 			DESCRIPTION
 * TLaw/ISal 	n/a 			GC Changes
 * CYu 			April 8 2014 	overriding core code
 * 						
 *
 ***********************************************************************/
	
	function gcRegistration_init() 
	{
		elgg_register_action('register/ajax', elgg_get_plugins_path() . "gcRegistration/actions/registerAJAX.php", 'public');
		elgg_register_action('register', elgg_get_plugins_path() . 'gcRegistration/actions/register.php', 'public');
	}
	
	register_elgg_event_handler('init','system','gcRegistration_init');		
?>