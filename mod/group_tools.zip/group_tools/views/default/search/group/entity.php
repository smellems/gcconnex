<?php
/**
 * search listing view for groups
 */

echo elgg_view_entity($vars["entity"]);
