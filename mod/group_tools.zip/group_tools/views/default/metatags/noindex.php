<?php
/**
 * Don't allow search engines to index this page
 */
?>
<meta name="robots" content="noindex" />
