<?php



echo 'hello world';

// extra space
echo "<br>";

