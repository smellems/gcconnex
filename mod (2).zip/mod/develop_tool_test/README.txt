
READ ME

Instructions:
======================

1. must run the bash script in order for this plugin to work (it needs permission to write)

to run bash script:
> chmod u+x search_lang_files.sh
> ./seaerch_lang_files.sh