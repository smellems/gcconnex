<?php


$english = array(

	'grp_just:member_info' => 'GCconnex Member Information',
	'grp_just:group_info' => 'GCconnex Group Information',
	'grp_just:justification' => 'Reason for joining',
	'grp_just:submit_app' => 'Submit Application',
	'grp_just:review_app' => 'Review Application',
	'grp_just:app_sent' => 'Application sent',
	'grp_just:apply' => 'Request Membership',
	'grp_just:applied' => 'Application sent',

);

add_translation("en",$english);
