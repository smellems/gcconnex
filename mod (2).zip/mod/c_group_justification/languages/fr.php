<?php

$french = array(
	'grp_just:member_info' => 'GCconnex d\'information du membres',
	'grp_just:group_info' => 'GCconnex d\'information du Groupe',
	'grp_just:justification' => 'Raison pour rejoindre',
	'grp_just:submit_app' => 'Soumettre',
	'grp_just:review_app' => 'Examen de la demande',
	'grp_just:app_sent' => 'Demande envoyée',
	'grp_just:apply' => 'Demander de devenir membre',
	'grp_just:applied' => 'Demande envoyée',
);

add_translation("fr",$french);