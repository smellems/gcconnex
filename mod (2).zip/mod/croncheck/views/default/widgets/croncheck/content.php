<?php

	echo elgg_view("croncheck/info", array("toggle" => true));