Elgg Extended Tinymce plugin for Elgg 1.8
Latest Version: 3.5.7
Released: 2012-10-07
Contact: iionly@gmx.de
License: GNU General Public License version 2
Copyright: (c) iionly 2012, (C) Curverider 2008-2010

The TinyMCE editor is licensed under
GNU Lesser General Public License version 2.1
(c) 2003-2012 Moxiecode Systems AB.
Website: http://www.tinymce.com/



An extended tinymce plugin based on version 3.5.7 of the TinyMCE editor.



Instructions:

1. Copy/extract the extended_tinymce archive into the mod folder,

2. Disable the Elgg core tinymce plugin,

3. Enable the extended_tinymce plugin.



Adding a language:

1. Download the language pack from http://www.tinymce.com/i18n/index.php?ctrl=lang&act=download,

2. Extract the files from the zip file,

3. Copy the langs, plugins, and themes directories into mod/extended_tinymce/vendor/tinymce/jscripts/tiny_mce/. There are already directories with those names but don't delete these existing directories but simply copy the files and folders included in the language pack over these directories,

4. Flush the Elgg caches via the admin dashboard on your site.
