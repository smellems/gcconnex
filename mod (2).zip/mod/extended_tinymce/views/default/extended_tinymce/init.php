<?php
/**
 * Initialize the TinyMCE script
 */

elgg_load_js('extended_tinymce');
elgg_load_js('elgg.extended_tinymce');