<?php
/**
 * Icons CSS
 */

echo elgg_view_module('info', 'Icon Sprites (.elgg-icon)', elgg_view('theme_preview/icons/sprites'));

echo elgg_view_module('info', 'Ajax Loader (.elgg-ajax-loader)', elgg_view('theme_preview/icons/loader'));

echo elgg_view_module('info', 'Avatars (.elgg-avatar)', elgg_view('theme_preview/icons/avatars'));
