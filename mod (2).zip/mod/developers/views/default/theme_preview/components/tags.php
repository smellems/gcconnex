<?php

echo elgg_view('output/tags', array(
	'value' => array('one', 'two', 'three', 'four', 'cinco'),
));
