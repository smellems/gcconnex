<?php
/**
 * CSS Preview
 */

$url = elgg_get_site_url() . 'theme_preview';
?>
<iframe id="developers-iframe" src="<?php echo $url; ?>"></iframe>