<!--<div class="mts float-alt">
<a href="http://fxnion.free.fr/"><img src="<?php echo elgg_get_site_url(); ?>mod/custom_index_widgets/images/fxnion_elgg_custom_index.gif" alt="Elgg Custom index by Fx Nion" title="Elgg Custom index by Fx Nion"/></a>
</div>-->
