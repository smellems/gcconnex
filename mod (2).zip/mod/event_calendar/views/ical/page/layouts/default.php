<?php
echo $vars['content'];