
.dyk-icon {
	background: transparent url(<?php echo elgg_get_site_url(); ?>mod/didyouknow/graphics/sprite.png) no-repeat left;
	background-position: 0 0;
	width: 16px;
	height: 16px;
	margin: 0 2px;
}
.dyk-icon-refresh {
	background-position: 0 0;
}
.dyk-icon-refresh:hover {
	background-position: 0 -16px;
}
