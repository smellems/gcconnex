<?php
/**
 * Remove admin notice to populate categories.
 */

elgg_delete_admin_notice('categories_admin_notice_no_categories');
