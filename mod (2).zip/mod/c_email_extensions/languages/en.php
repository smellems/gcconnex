<?php


$english = array(

	'c_ext:id' => 'ID',
	'c_ext:ext' => 'Extension',
	'c_ext:dept' => 'Department',
	'c_ext:add_new_ext' => 'Add new extension',
	'c_ext:add' => 'Add',
	'c_ext:delete' => 'Delete',

);

add_translation("en",$english);
