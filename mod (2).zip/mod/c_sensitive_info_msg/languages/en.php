<?php

$english = array(

	'c_sensitive_info_msg:friendly_reminder' => '<p><strong>Friendly reminder:<br/> </strong>As per the <a href="http://gcconnex.gc.ca/terms">Terms and Conditions of use of GCconnex</a>, sensitive or confidential content is not to be posted on GCconnex. This means that only "unprotected", "unclassified" or "Protected A" document should be posted. The <a href="http://www.tbs-sct.gc.ca/pol/doc-eng.aspx?id=1245">Policy on Access to Information</a> applies to all information posted on GCconnex.</p>',

);

add_translation('en', $english);