<?php

$french = array(

	'c_sensitive_info_msg:friendly_reminder' => '<p><strong>Rappel amical</strong> :<br/> Conform&eacute;ment aux <a href="http://gcconnex.gc.ca/terms">Conditions d&rsquo;utilisation de GCconnex</a> et aux <a href="http://www.gcpedia.gc.ca/wiki/GCpedia:Conditions_d%27utilisation">Conditions d&rsquo;utilisation de GCp&eacute;dia</a>, aucun contenu de nature sensible, confidentielle ou inappropri&eacute;e ne peut &ecirc;tre publi&eacute; sur les Outils GC2.0. Cela signifie que seuls des documents &laquo;&nbsp;non prot&eacute;g&eacute;s&nbsp;&raquo;, &laquo;&nbsp;non classifi&eacute;s&nbsp;&raquo; ou &laquo;&nbsp;Prot&eacute;g&eacute; A&nbsp;&raquo; peuvent &ecirc;tre affich&eacute;s.&nbsp;</p>',

);

add_translation('fr', $french);
