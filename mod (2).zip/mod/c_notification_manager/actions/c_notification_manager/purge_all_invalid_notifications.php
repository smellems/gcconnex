<?php

	// retrieving entity object from the database
	$resultset = elgg_get_entities(array(
		'type' => 'object',
		'subtype' => 'gc_notification'));


	foreach ($resultset as $result)
	{
		$result->delete();
	}

forward(REFERER);