<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$mobile_language[0] = 'Chat';
$mobile_language[1] = 'Users Online for Chat';
$mobile_language[2] = 'X';
$mobile_language[3] = 'Lobby';
$mobile_language[4] = 'No users online at the moment.';
$mobile_language[5] = 'Sorry you have logged out';
$mobile_language[6] = 'Me';
$mobile_language[7] = ':  ';
$mobile_language[8] = 'X';
$mobile_language[9] = 'Type your message';
$mobile_language[10] = 'Username';
$mobile_language[11] = 'Password';
$mobile_language[12] = 'Login';
$mobile_language[13] = 'Username and password do not match';
$mobile_language[14] = 'Username or password cannot be blank';
$mobile_language[15] = 'Search User';
$mobile_language[16] = 'Search Chatroom';
$mobile_language[17] = 'Type your message';
$mobile_language[18] = 'Chat';
$mobile_language[19] = 'Chatroom';
$mobile_language[20] = 'One-on-One Chat';
$mobile_language[21] = 'Chatrooms';
$mobile_language[22] = 'Create Chatroom';
$mobile_language[23] = 'Users';
$mobile_language[24] = 'Back';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////