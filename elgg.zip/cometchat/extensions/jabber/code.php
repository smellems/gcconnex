<?php
$extensioninfo = array('jabber','Facebook/Gtalk/XMPP Chat');