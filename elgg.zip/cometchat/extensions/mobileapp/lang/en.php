<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$mobileapp_language[0] = 'Chat';
$mobileapp_language[1] = 'Users Online for Chat';
$mobileapp_language[2] = 'X';
$mobileapp_language[3] = 'Lobby';
$mobileapp_language[4] = 'No users online at the moment.';
$mobileapp_language[5] = 'Sorry you have logged out';
$mobileapp_language[6] = 'Me';
$mobileapp_language[7] = ':  ';
$mobileapp_language[8] = 'X';
$mobileapp_language[9] = 'Type your message';
$mobileapp_language[10] = 'Username';
$mobileapp_language[11] = 'Password';
$mobileapp_language[12] = 'Login';
$mobileapp_language[13] = 'Username and password do not match';
$mobileapp_language[14] = 'Username or password cannot be blank';
$mobileapp_language[15] = 'Search User';
$mobileapp_language[16] = 'Search Chatroom';
$mobileapp_language[17] = 'Type your message';
$mobileapp_language[18] = 'Chat';
$mobileapp_language[19] = 'Chatroom';
$mobileapp_language[20] = 'One-on-One Chat';
$mobileapp_language[21] = 'Chatrooms';
$mobileapp_language[22] = 'Create Chatroom';
$mobileapp_language[23] = 'Users';
$mobileapp_language[24] = 'Back';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////