<?php
$extensioninfo = array('mobiletab','Mobile Tab');
?>