<?php
$trayiconinfo = array('announcements','Announcements');
$trayicondata = 'JHRyYXlpY29uW10gPSBhcnJheSgnYW5ub3VuY2VtZW50cycsJ0Fubm91bmNlbWVudHMnLCdtb2R1bGVzL2Fubm91bmNlbWVudHMvaW5kZXgucGhwJywnX3BvcHVwJywnMjgwJywnMzEwJywnJywnMScsJycpOw==';