<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$games_language[100] = 'Jeux';
$games_language[1] = 'Trouver un jeu ici';
$games_language[2] = 'Chargement en cours. Veuillez patienter...';
$games_language[3] = 'Aucun jeu sur le serveur';
$games_language[4] = 'Highest Scored Games';
$games_language[5] = 'Leaderboard';
$games_language[6] = 'Please log in to use this feature';
$games_language[7] = 'Latest Played Games';
$games_language[8] = 'User';
$games_language[9] = 'Score';
$games_language[10] = 'Games';
$games_language[11] = 'No scores yet! Be the first to add your name to the leaderboard.';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////