<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$games_language[100] = 'Single Player Games';
$games_language[1] = 'Find a Game here';
$games_language[2] = 'Loading please wait...';
$games_language[3] = 'No Games present at the server';
$games_language[4] = 'Highest Scored Games';
$games_language[5] = 'Leaderboard';
$games_language[6] = 'Please log in to use this feature';
$games_language[7] = 'Latest Played Games';
$games_language[8] = 'User';
$games_language[9] = 'Score';
$games_language[10] = 'Games'; 
$games_language[11] = 'No scores yet! Be the first to add your name to the leaderboard.'; 



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

?>