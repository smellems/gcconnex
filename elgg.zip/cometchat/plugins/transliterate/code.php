<?php
$plugininfo = array('transliterate','Transliterate');