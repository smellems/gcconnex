<?php
$plugininfo = array('chattime','Chat Time');