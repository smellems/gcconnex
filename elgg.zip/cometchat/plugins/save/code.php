<?php
$plugininfo = array('save','Save Conversation');