<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$writeboard_language[0] = 'Share a collaborative document';
$writeboard_language[1] = 'Please wait atleast 10 seconds before trying to share again.';
$writeboard_language[2] = 'has shared a document.';
$writeboard_language[3] = 'Click here to view the document';
$writeboard_language[4] = 'or simply ignore this message.';
$writeboard_language[5] = 'has successfully shared a document.';
$writeboard_language[6] = 'is now viewing your document.';
$writeboard_language[7] = 'Collaborative document';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////