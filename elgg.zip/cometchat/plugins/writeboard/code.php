<?php
$plugininfo = array('writeboard','Writeboard');