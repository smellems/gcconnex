<?php
$plugininfo = array('whiteboard','Whiteboard');