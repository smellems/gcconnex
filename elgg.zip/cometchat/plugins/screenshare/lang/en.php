<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$screenshare_language[0] = 'Share my screen';
$screenshare_language[1] = 'Please wait atleast 10 seconds before trying to share again.';
$screenshare_language[2] = 'has shared his/her screen with you.';
$screenshare_language[3] = 'Click here to view his/her screen';
$screenshare_language[4] = 'or simply ignore this message.';
$screenshare_language[5] = 'has successfully shared his/her screen.';
$screenshare_language[6] = 'is now viewing your screen.';
$screenshare_language[7] = 'Screen sharing';
$screenshare_language[8] = 'Refresh list';
$screenshare_language[9] = 'Which window would you like to share?';
$screenshare_language[10] = 'Install plug-in';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////