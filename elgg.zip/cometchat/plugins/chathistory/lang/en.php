<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$chathistory_language[0] = 'View chat history';
$chathistory_language[1] = 'Me';
$chathistory_language[2] = 'Chat Conversation with';
$chathistory_language[3] = 'lines';
$chathistory_language[4] = 'on';
$chathistory_language[5] = 'Back';
$chathistory_language[6] = 'Chat History';
$chathistory_language[7] = 'Chat Conversation in chatroom';
$chathistory_language[8] = 'Click here to view entire conversation';
$chathistory_language[9] = 'No previous conversation to view';


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////