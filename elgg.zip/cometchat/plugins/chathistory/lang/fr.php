<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$chathistory_language[0] = 'Voir l\'historique du clavardage';
$chathistory_language[1] = 'Moi';
$chathistory_language[2] = 'Conversation avec';
$chathistory_language[3] = 'lignes';
$chathistory_language[4] = 'le';
$chathistory_language[5] = 'Précédent';
$chathistory_language[6] = 'Historique de clavardage ';
$chathistory_language[7] = 'Conversation dans le clavardoir ';
$chathistory_language[8] = 'Cliquez ici pour voir toute la conversation';
$chathistory_language[9] = 'Aucune conversation à voir ';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////