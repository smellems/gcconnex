<?php
$plugininfo = array('handwrite','Handwrite a message');