<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$broadcast_language[0] = 'Start an audio/video broadcast';
$broadcast_language[1] = 'Please wait atleast 10 seconds before trying to broadcast again.';
$broadcast_language[2] = 'has sent you an audio/video broadcast request.';
$broadcast_language[3] = 'Click here to accept it';
$broadcast_language[4] = 'or simply ignore this message.';
$broadcast_language[5] = 'has successfully sent an audio/video broadcast request.';
$broadcast_language[6] = 'has accepted your audio/video broadcast request.';
$broadcast_language[7] = 'Click here to launch the broadcasting window';
$broadcast_language[8] = 'Audio/Video Broadcast';
$broadcast_language[9] = 'has started broadcasting.';
$broadcast_language[10] = 'Click here to join the broadcast.';
$broadcast_language[11] = 'Please select users';
$broadcast_language[12] = 'Invite Users';
$broadcast_language[13] = 'Invite Users';
$broadcast_language[13] = 'Users Invited Successfully!';
$broadcast_language[14] = 'has invited you to join the broadcast.';
$broadcast_language[15] = 'Click here to join';
$broadcast_language[16] = 'Click here to join the conversation.';
$broadcast_language[17] = 'has started a video conversation.';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////