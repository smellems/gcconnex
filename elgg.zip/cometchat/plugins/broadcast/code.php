<?php
$plugininfo = array('broadcast','Audio/Video Broadcast');