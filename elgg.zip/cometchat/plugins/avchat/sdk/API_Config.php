<?PHP

/*!
* OpenTok PHP Library
* http://www.tokbox.com/
*
* Copyright 2010, TokBox, Inc.
*
*/

class API_Config {

	const SDK_VERSION = "tbphp-v0.91.2011-02-14";

}
