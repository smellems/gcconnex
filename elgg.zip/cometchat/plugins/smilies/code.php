<?php
$plugininfo = array('smilies','Smilies');