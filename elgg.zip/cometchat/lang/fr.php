<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$rtl = '0';
$language[0] = 'Options de clavardage';
$language[1] = 'Écrivez votre statut et appuyez sur la touche Entrée!';
$language[2] = 'Mon statut';
$language[3] = 'Disponible';
$language[4] = 'Occupé(e)';
$language[5] = 'Invisible';
$language[6] = '';
$language[7] = '';
$language[8] = 'Veuillez vous connecter pour pouvoir utiliser le clavardage';
$language[9] = 'Voir qui est en ligne';
$language[10] = 'Moi';
$language[11] = 'Hors ligne';
$language[12] = 'Voir qui est en ligne';
$language[13] = 'Désactiver les notifications sonores';
$language[14] = 'Il n\'y a aucune collègue dans votre liste de collègues, veuillez ajouter quelques collègues afin de pouvoir utiliser le clavardage';
$language[15] = 'Vous avez des nouveaux messages…';
$language[16] = '';
$language[17] = 'Hors ligne';
$language[18] = 'Trouver un utilisateur';
$language[19] = '<br/><span style=\'color:#999\'>est en ligne</span>';
$language[20] = '<br/><span style=\'color:#999\'>est en ligne</span>';
$language[21] = '<br/><span style=\'color:#999\'>est en ligne (occupé[e])</span>';
$language[22] = 'Modifier mon statut';
$language[23] = 'Je suis…';
$language[24] = 'Désactiver les notifications par fenêtres contextuelles ';
$language[25] = '';
$language[26] = 'Commencer à clavarder';
$language[27] = 'Fermer cette barre d\'outils';
$language[28] = 'Il n\'y a aucun utilisateur en ligne pour l\'instant. Veuillez réessayer plus tard.';
$language[29] = 'Vous n\'avez aucun collègue en ligne pour l\'instant. Veuillez réessayer plus tard.';
$language[30] = 'Je suis disponible';
$language[31] = 'Je suis occupé(e)';
$language[32] = 'Je suis hors ligne';
$language[33] = 'Je suis hors ligne';
$language[34] = 'Je suis absent(e)';
$language[35] = ' | ';
$language[36] = 'et';
$language[37] = 'plus de notifications';
$language[38] = 'Cette fenêtre est déjà ouverte. Veuillez fermer la fenêtre existante et réessayer.';
$language[39] = 'Quitter cette page entraînera la fermeture de vos fenêtres de clavardage.';
$language[40] = 'Autres';
$language[41] = 'Chargement en cours...';
$language[42] = '';
$language[43] = 'Mon nom';
$language[44] = 'Régler mon nom';
$language[45] = 'Écrivez votre nom/statut et appuyez sur la touche Entrée!';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////