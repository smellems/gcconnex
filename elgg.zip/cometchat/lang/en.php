<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$rtl = '0';
$language[0] = 'Chat Options';
$language[1] = 'Type your status and hit the enter key!';
$language[2] = 'My Status';
$language[3] = 'Available';
$language[4] = 'Busy';
$language[5] = 'Invisible';
$language[6] = '';
$language[7] = '';
$language[8] = 'Please login to use chat';
$language[9] = 'Who\'s Online';
$language[10] = 'Me';
$language[11] = 'Offline';
$language[12] = 'Who\'s Online';
$language[13] = 'Disable sound notifications';
$language[14] = 'You have no friends in your friend list, please add a few friends to use chat';
$language[15] = 'New Messages...';
$language[16] = '';
$language[17] = 'Offline';
$language[18] = 'Find a user';
$language[19] = '<br/><span style=\'color:#999\'>is online</span>';
$language[20] = '<br/><span style=\'color:#999\'>is offline</span>';
$language[21] = '<br/><span style=\'color:#999\'>is online (busy)</span>';
$language[22] = 'Set my status';
$language[23] = 'I am...';
$language[24] = 'Disable popup notifications';
$language[25] = '';
$language[26] = 'Start chatting!';
$language[27] = 'Close this bar';
$language[28] = 'No users online at the moment. Please try again later.';
$language[29] = 'No friends online at the moment. Please try again later.';
$language[30] = 'I\'m available';
$language[31] = 'I\'m busy';
$language[32] = 'I\'m offline';
$language[33] = 'I\'m offline';
$language[34] = 'I\'m away';
$language[35] = ' | ';
$language[36] = 'And ';
$language[37] = ' more notifications';
$language[38] = 'This popup is already open. Please close the existing popup and try again.';
$language[39] = 'Navigating away from this page will close your chat popups.';
$language[40] = 'Others';
$language[41] = 'Loading...';
$language[42] = '';
$language[43] = 'My Name';
$language[44] = 'Set my name';
$language[45]= 'Type your Name/Status and hit the enter key!';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////